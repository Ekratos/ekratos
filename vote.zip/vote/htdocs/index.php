<? 
error_reporting(E_ERROR | E_PARSE);

set_include_path("/URLVOTE");
include "../prepend.php";
include_once "functionsEkratos.php"; ?>

<?
if ($_GET['lang']) $_SESSION['lang']=$_GET['lang'];
if (!$_SESSION['lang']) $_SESSION['lang']='ca';
$lang=$_SESSION['lang'];


$blocks=array();
#include "usersEkratos.php";
$current=array_shift($peticion);
$votingLic=array_shift($peticion);
$vhash=array_shift($peticion);
#$vhash=strtoupper(substr(current(explode("-",$_SERVER['HTTP_HOST'])),2));

#xalert($votinghash);
#if (!$voting=votingOfUrl($vhash)) $current='vote';
#if (!$voting2=votingOfIdent($vhash)) $current='vote';
#if (!$voting2->votingId==$voting->votingId) $current='vote';
sleep ("1.".rand(15,55));

if ($_GET['box']) $_SESSION['isqr']=$_GET['box'];

xalert("vl: $votingLic<br>vh: $vhash<br>st: $_SESSION[token1]<br>pt: $_POST[token1]<br>id:$_SESSION[identifier]");
if (fnmatch("qr",$current)) $fail=908;
elseif (!fnmatch("[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]",$votingLic)) $fail=808;
elseif (!fnmatch("[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]",$vhash)) $fail=809;
elseif ($_POST['token1'] and $_SESSION['token1'] and $_POST['token1']==$_SESSION['token1']) $current='vote2';
elseif ($_POST['voting1']) $current='vote5';
elseif ($_POST['confirming1']) $current='vote6';
//elseif ($_SESSION['identifier']==$vhash) $current=$current;
//else $current='vote';

xalert($current);

if (!$fail) switch ($current) {
case 'vote':
		$_SESSION['token1']=genLicense().genLicense();
		$fail=200;
                break;  
case 'vote2':
		xalert(separator." 32" );
		if (!$_POST['identifier']) 			{$fail=403; break;}
		if (!$voting=votingOfLic($votingLic)) 		{$fail=408; break;}
		if (!$voting2=votingOfIdent($vhash)) 		{$fail=407;break;}
		if (!$voting2->votingId==$voting->votingId) 	{$fail=406;break;}
		if (!$_POST['token1']==$_SESSION['token1'])	{$fail=402; break;}
		xalert(separator." 33" );
		if (!$votingb=votingOfIdent($vhash,$_POST['identifier'])) {$fail=405; break;}
		xalert($votingb,votingb);
		if (!$voting->votingId==$votingb->votingId) 	{$fail=409; break;}
		if ($voting->status!='21.voting') 	{
				$_SESSION['error']='voting closed'; 
				die ("<script>window.location.replace(\"/vote/$voting->votinglicense/$vhash\")</script>");
		}
		$xvoter=voterOfIdent($vhash);
		if (!$xvoter or $xvoter->hasvoted) { 
				$_SESSION['error']='already voted'; 
				die ("<script>window.location.replace(\"/vote/$voting->votinglicense/$vhash\")</script>");
		}

		$_SESSION['identifier']=$vhash;
		$_SESSION['voting']=$voting->votinglicense;

		foreach(Sfieldsof($voting) as $s) $statistic[$s->id]=$xvoter->{$s->id};
		$_SESSION['statistic']=$statistic;
		if (!$_SESSION['votetoken1']) $_SESSION['votetoken1']=genLicense();
		die ("<script>window.location.replace(\"/vote3/$voting->votinglicense/$vhash\")</script>");
		break;
case 'printqr':
	//	print_r($_SESSION['rebut']);
		die ("<script>location.replace(\"/qr\")</script>");
		break;
case 'vote6':
case 'vote5':
case 'vote4':
case 'vote3':
		if (!$voting=votingOfLic($votingLic)) 		{$fail=408; break;}
		if (!$voting2=votingOfIdent($vhash)) 		{$fail=407;break;}
		if (!$voting2->votingId==$voting->votingId) 	{$fail=406;break;}
		$xvoter=voterOfIdent($vhash);
		if ($voting->status!='21.voting')       {
                                $_SESSION['error']='voting closed';
                                die ("<script>window.location.replace(\"/vote/$voting->votinglicense/$vhash\")</script>");
                }
	
		if (!$xvoter or $xvoter->hasvoted) { 
                                $_SESSION['error']='already voted'; 
                                die ("<script>window.location.replace(\"/vote/$voting->votinglicense/$vhash\")</script>");
                }

		if (!$voting=votingOfLic($votingLic)) 		{$fail=418; break;}
		if (!$_SESSION['identifier'] or  !$_SESSION['identifier']==$vhash)	{$fail=413; break;}
		$blocks[]="vote-head";
		$blocks[]="vote-nav"	;
                $blocks[]=$current;
                $blocks[]="vote-footer"    ;
                break;

default:
		header("HTTP/1.0 404 Not Found");	
		$fail=404;
		break;
}

if ($fail>0) {  
		killsession($fail);
		$blocks[]="vote-head";
                if ($fail>900) {
			$blocks[]="readqr";
		}
                elseif ($fail>800) $blocks[]="vote-exit";
		else $blocks[]="vote-main";
		header("HTTP/1.0 404 Not Found");
//		if ($current!='vote') die ("<script>location.replace(\"/vote/$voting->votinglicense/$vhash\")</script>");
		xalert($fail,"fail!!!");
}
xalert($blocks,"Blocks");
if ($_POST) xalert($_POST,"POST");
if ($_SESSION) xalert($_SESSION,"SESSION");
$blocks[]="xalert";
?>

<?
foreach ($blocks as $block) {
        if(!$block) continue;
//      echo "\n\n<a style='margin-top:-80px;position:absolute' name='$block'></a>\n";
//        if (!$_GET['simple']) echo "<section class=\"site-wrapper\" id=\"block$block\">";
        include "block/$block.php";
//        if (!$_GET['simple']) echo "</section>";
}

?>

