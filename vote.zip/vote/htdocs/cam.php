<script>

location="https://webrtc.github.io/samples/src/content/devices/input-output/"
</script>
