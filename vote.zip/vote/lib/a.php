<?
exit;
while ($note < 6) {
$note ++;
echo $note.": ";
echo md5("9eKrat87EA.$note.B.9OLz.9ea");
echo "\n";
}
