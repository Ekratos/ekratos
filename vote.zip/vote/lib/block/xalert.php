<?
if (isset($_GET['xalert'])) $_SESSION['xalert']=$_GET['xalert'];
if (!$_SESSION['xalert']) return;

 foreach ($_SERVER['xalert'] as $msg){ ?>
        <section style=" margin:30px; padding: 10px;border:2px solid #444222; border-radius:8px; "><?=$msg?></section>

<? } ?>
