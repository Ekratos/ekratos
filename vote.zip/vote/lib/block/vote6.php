<?

$rebut=genLicense();
$date=date("d/m/y");
$hour=date("H:i:s");
$ip=$_SERVER['REMOTE_ADDR'];
$voter=voterOfIdent($vhash);
foreach(SfieldsOf($voting) as $field) $extradata.=",".$voter->{$field->id};
foreach(AfieldsOf($voting) as $field) $extradata.=",".$voter->{$field->id};

foreach($_POST as $k=>$v) file_put_contents("/var/www/manage/log/vote.$voting->votinglicense.log","$rebut,$date,$hour,$ip,$voting->votinglicense,$k,$v$extradata\n",FILE_APPEND);

foreach($_POST as $k=>$v) file_put_contents("/var/www/manage/log/vote2.$voting->votinglicense.log",mysql_escape_string("$rebut,$date,$hour,$ip,$voting->votinglicense,$k,$v$extradata")."\n",FILE_APPEND);
if ($_SESSION['isqr']) $add=",hasvotedin='$_SESSION[isqr]' ";
else $add='';
#xalert("$rebut,$date,$hour,$ip,$voting->votinglicense,$k,$v$extradata");
wquery("update voter set hasvoted='S'$add where voterId=$voter->voterId");

if ($box=$_SESSION['isqr']) file_put_contents("/var/www/manage/log/box.$box.spool","\n\n".$voting->{"title_lang$lang"}."\n\n\nREBUT DE VOT\n\n\n".substr($rebut,0,24)."\n\n\nData: $date\nhora: $hour\n\n\n\nGràcies per participar\n\n\n\n\n\n\n ",FILE_APPEND);

if ($box=$_SESSION['isqr']) file_put_contents("/var/www/manage/log/box2.$box.spool","\n\n".$voting->{"title_lang$lang"}."\n\n\nREBUT DE VOT\n\n\n".substr($rebut,0,24)."\n\n\nData: $date\nhora: $hour\n\n\n\nGràcies per participar\n\n\n\n\n\n\n ",FILE_APPEND);
?>


	<!--benvinguda -->
    	<div id="info" class="content-section-b ">
		<div class="container">
		  <div class="row">
          <div class="container">
		
        
            <div class="row bs-wizard" style="border-bottom:0;">
                
              <div class="col-xs-4 bs-wizard-step complete">
                  <div class="text-center bs-wizard-stepnum"><?t("Wellcome")?></div>
                 <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step complete"><!-- complete -->
                  <div class="text-center bs-wizard-stepnum"><?t("Voting")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step complete"><!-- complete -->
                  <div class="text-center bs-wizard-stepnum"><?t("Validation")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step active"><!-- active -->
                  <div class="text-center bs-wizard-stepnum"><?t("Ticket")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
            </div>  
	</div>
		<div class="container">
		  <div class="row">

<form method="post" >
<input type="hidden" name="confirming1" value="1">

			<div class="col-md-6 col-md-offset-3 text-center">
				<h2><?t("Rebut de Vot")?></h2>
<div class="lead">
				<p><strong><?t("The vote has been cast")?></strong></p>
				<p><?t("This is a receipt certifying")?></p>
				<p><?t("Click the Print button to keep")?></p>
				<p><?t("Rebut de Vot")?>: <?=$rebut?></h2></p>
				<p>Ip: <?=$_SERVER['REMOTE_ADDR']?></h2></p>
				<p>Data: <?=$date?></h2></p>
				<p>Hora: <?=$hour?></h2></p>
</div>
			</div>
<center>
<? if ($_SESSION['isqr']) { ?>
	<a class="btn btn-embossed btn-primary" onclick="location.replace('/qr')" href="#" role="button"><i class="fa fa-sign-out" aria-hidden="true"></i> Sortir</a>
<? } else { ?>
	<a class="btn btn-embossed btn-primary" onclick="location.replace('/vote/')" href="#" role="button"><i class="fa fa-sign-out" aria-hidden="true"></i> Sortir</a>
	<a class="btn btn-embossed btn-primary" onclick="window.print()" href="#" role="button"><i class="fa fa-print" aria-hidden="true"></i> Imprimir</a>
<? } ?>
</center>
</form>
		</div>
	</div>	
</div>	
	
