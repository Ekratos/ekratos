	<!--benvinguda --><!-- <?t("Voting")?> -->
<section id="votacio" class="content-section-b">
        <div class="container">
                    <div class="row bs-wizard" style="border-bottom:0;">
                
              <div class="col-xs-4 bs-wizard-step complete">
                  <div class="text-center bs-wizard-stepnum"><?t("Wellcome")?></div>
                 <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step active"><!-- complete -->
                  <div class="text-center bs-wizard-stepnum"><?t("Voting")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step disabled"><!-- complete -->
                  <div class="text-center bs-wizard-stepnum"><?t("Validation")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step disabled"><!-- active -->
                  <div class="text-center bs-wizard-stepnum"><?t("Ticket")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
            </div>  
<form method="post" action="">
<input type="hidden" name="voting1" value="1">
			 <div class="col-md-6 col-md-offset-3 text-center wrap_title ">
			   <h2><?t("Voting")?></h2>
<? foreach (getQuestions($voting) as $question) { 
$qn++;
?>
	<div question="1">
			   <h4><?=$question->{"statement_lang$lang"}?></h4>

<style>
:checked + div{ background:#cfcfcf; border:#333 }
</style>
	<?/*if ($question->hasimage=='S') { ?> <p><?t("(Click on the image to see it")?></p><? } */?>
<? 
$on=0;
?>
<style>
div[option] input[type='checkbox']{
	position:absolute;margin:10px;
}
</style>
<?$options=getOptions($question);
if ($question->orderable) shuffle($options);
foreach ($options as $option) {
$on++;
$points=sizeof($options)+1-$on;
?>
      <div option="1" style="background:#f5f5f5;clear:both;text-align:left; margin-bottom:5px; border:1px solid #5f5f5f;border-radius:8px;">

<? if ($question->orderable) { ?>
	<div style="position:absolute;margin:10px;text-align:center">	
	<img src="/img/up2.png"><br>
	<div points="1"><span><?=$points?></span>&nbsp;&nbsp;<small><?t("points");?></small></big></div>
	</div>
          <input class="question-<?=$qn?>" checked style="display:none" <?=$allchecked?> type="checkbox" name="<?=$_SESSION['votetoken1']?>-<?=$question->questionlicense?>-<?=$option->optionlicense?>" value="1">
<? } else { ?>
	  <label style="min-height:52px;width:100%; margin:0 ">
          <input class="question-<?=$qn?>" type="checkbox" name="<?=$_SESSION['votetoken1']?>-<?=$question->questionlicense?>-<?=$option->optionlicense?>" value="1">
<?}?>
<div style="padding:10px;border-radius:8px">
	<center>
	<? if (strlen($option->logo)>1) { ?>
<?/*	<img src="data:image;base64,<?=$option->logo?>" alt="" width="" height="56"><br> */?>
	<img src="https://cdn.vota.online/upsource/<?=$option->optionlicense?>" alt="" width="" height="66" ><br>
	<?}?><big>
	<?if (!$text=$option->{"statement_lang$lang"}) $text=$option->name; echo $text?>
	</big>
	</center>
	</div>
	</label>
        </div>
	<? } ?>
<?
$on++;
?>
<?/*
	  <tr>
	<td width="59%" height="72" style="margin:0;padding:0">
          <label style="height:72px;width:100%; padding:10px 0">
          <input class="question-<?=$qn?>" style="margin:0 20px" type="checkbox" name="" value="opcio1">
           Opció <?=$on?> - <?t("blank vote")?>
        </label>
        </td>
        <td width="40%"><div alt="" width="200" height="56"></div></td>
      </tr>
*/?>

<script>
<? if ($question->orderable!='S') { ?>
var limit<?=$question->questionId?> = <? if ($question->maxoptions) echo $question->maxoptions; else echo 1;?>;
$('input.question-<?=$qn?>').on('change', function(evt) {
   if($(this).closest("div[question]").find(":checked").length > limit<?=$question->questionId?>) {
       this.checked = false;
	alert("màxim "+limit<?=$question->questionId?>+" respostes");
   }
});
<? } else { ?>
$(document).on("click","[option]",function(event){
        var other=$(this).prev("div[option]");
        if (!$(other).attr("option")) return;
        var points=$(other).find("div[points] span").text();
        $(this).find("div[points] span").text(points);
        $(other).find("div[points] span").text(points -1);
        $(this).after('<div option="1" new="1" style="display:none;background:#f5f5f5;clear:both;text-align:left; margin-bottom:5px">'+other.html()+'</div>');
        $(other).slideUp(300,function() { $(this).remove() ; $("div[new]").slideDown(300);  })
//      alert($(this).attr('dest'));
        
});

<? }?>
</script>
</div>
 <? } ?>
	<p>
	<?include "button-exit.php"?>

<button type="submit" class="btn btn-success" role="button"><i class="fa fa-envelope" aria-hidden="true"></i> Votar
</button> 

</form>
			   </div>
		
		  </div>
</div>
        </div>

	</section>

	
