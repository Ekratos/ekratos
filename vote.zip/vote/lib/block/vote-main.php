<div style="position:absolute;left:50%;font-size:40%;color:white"><?=$_SESSION['isqr']?></div>
<div class="intro-header">
		<div class="col-xs-12 text-center abcen1">
			<h1 class="h1_home wow fadeIn animated animated" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s;"><img src="/img1/logo.png" width="154" alt=""></h1>
			<h3 class="h3_home wow fadeIn animated animated" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s;"><?t("Benvingut a la plataforma")?></h3>
				<p class="lead" style="margin-top:0"><?

if ($votingLic=='15BXSFXO-6SP8E-6RQ8N-OGGH72JL-8174I9AT') t("Indica el teu id col");
else t("Indica el teu document");
?></p>

		  <ul class="list-inline intro-social-buttons">
			<? if ($_SERVER['error']) { ?>
			<h3 class="h2_home wow fadeIn animated animated error"><br><?=t($_SERVER['error'])?><br><br></h3>
			<? } ?>
			<form method="post">
			<li id="download">
			<input type="hidden" name="token1" value="<?=$_SESSION['token1']?>">
				<input type="text"  name="identifier" value="" required autocomplete="off" autofocus style="height:45px; padding:10px;color:black;font-size:120%;border-radius:4px;border:none;text-align:center"><br><br>
			<?include("button-exit.php")?>
<input type="submit" class="btn btn-success" data-wow-delay="1.2s" style="visibility: visible; animation-delay: 1.2s;" value="<?t("Start Voting")?>"></li>

			</form>
			</ul>
		</div>    
        <!-- /.container -->
		<div class="col-xs-12 text-center abcen wow fadeIn animated animated" style="display:none;visibility: visible;">
			<div class="button_down "> 
				<a class="imgcircle wow bounceInUp animated animated" data-wow-duration="1.5s" href="#consulta" style="visibility: visible; animation-duration: 1.5s;"> <img class="img_scroll" src="/img/icon/circle.png" alt=""> </a>
			</div>
		</div>
    </div>
