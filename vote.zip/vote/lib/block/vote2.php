<? print_r($voting) ?>
