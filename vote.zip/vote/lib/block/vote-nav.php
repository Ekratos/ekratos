        <!-- NavBar-->

<? $institution=institutionOf($voting);?>
        <nav class="navbar-default" role="navigation">
                <div class="container">
                        <div class="navbar-header">
                                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                                        <span class="sr-only"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand" href="index.html"><img src="/img1/logo.png" width="" height="55" alt=""/></a>
                        </div>

                        <div class="collapse navbar-collapse navbar-right navbar-ex1-collapse">
                <ul class="nav navbar-nav">
<? foreach (explode(",",$voting->langs) as $l) {
?>
                                       <li class="menuItem"><a href="<?="/$current/$voting->votinglicense/$vhash?lang=$l"?>"><?t("lang $l")?></a>
</li><?
$add=" | ";
}
?>
                                </ul>
                        </div>

                </div>
        </nav>
