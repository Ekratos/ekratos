<div class="intro-header">
		<div class="col-xs-12 text-center abcen1">
			<h1 class="h1_home wow fadeIn animated animated" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s;"><img src="/img1/logo.png" width="154" alt=""></h1>
			<h3 class="h3_home wow fadeIn animated animated" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s;"><?t("Estas fora")?></h3>
				<p class="lead" style="margin-top:0"></p>

		  <ul class="list-inline intro-social-buttons">
			<? if ($_SERVER['error']) { ?>
			<h3 class="h2_home wow fadeIn animated animated error"><br><?=t($_SERVER['error'])?><br><br></h3>
			<? } ?>
			<form method="post">

			</form>
			</ul>
		</div>    
        <!-- /.container -->
		<div class="col-xs-12 text-center abcen wow fadeIn animated animated" style="display:none;visibility: visible;">
			<div class="button_down "> 
				<a class="imgcircle wow bounceInUp animated animated" data-wow-duration="1.5s" href="#consulta" style="visibility: visible; animation-duration: 1.5s;"> <img class="img_scroll" src="/img/icon/circle.png" alt=""> </a>
			</div>
		</div>
    </div>
