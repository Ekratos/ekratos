    <footer>
      <div class="container">
        <div class="row"><!-- /col-xs-7 --></div>
      </div>
    </footer>

    <!-- JavaScript -->
    <script src="/js/jquery-1.10.2.js"></script>
    <script src="/js/bootstrap.js"></script>
	<script src="/js/owl.carousel.js"></script>
	<script src="/js/script.js"></script>
	<!-- StikyMenu -->
	<script src="/js/stickUp.min.js"></script>
	<script type="text/javascript">
	  jQuery(function($) {
		$(document).ready( function() {
		  $('.navbar-default').stickUp();
		  
		});
	  });
	
	</script>
	<!-- Smoothscroll -->
	<script type="text/javascript" src="/js/jquery.corner.js"></script> 
	<script src="/js/wow.min.js"></script>
	<script>
	 new WOW().init();
	</script>
	<script src="/js/classie.js"></script>
	<script src="/js/uiMorphingButton_inflow.js"></script>
	<!-- Magnific Popup core JS file -->
	<script src="/js/jquery.magnific-popup.js"></script> 
</body>

</html>
