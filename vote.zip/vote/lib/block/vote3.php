
    
	<!-- Screenshot -->
	<!--benvinguda -->
    	<div id="info" class="content-section-b ">
		<div class="container">
		  <div class="row">
          <div class="container">
		
        
            <div class="row bs-wizard" style="border-bottom:0;">
                
              <div class="col-xs-4 bs-wizard-step active">
                  <div class="text-center bs-wizard-stepnum"><?t("Wellcome")?></div>
                 <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step disabled"><!-- complete -->
                  <div class="text-center bs-wizard-stepnum"><?t("Voting")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step disabled"><!-- complete -->
                  <div class="text-center bs-wizard-stepnum"><?t("Validation")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step disabled"><!-- active -->
                  <div class="text-center bs-wizard-stepnum"><?t("Ticket")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
            </div>  
	</div>
</div>
			<div class="col-md-6 col-md-offset-3 text-center">
				<h2><?t("Wellcome")?> </h2>
				<p class="lead" style="margin-top:0"><br><?=nl2br($voting->{"description_lang$lang"})?></p>
			 </div>
			<div class="col-md-6 col-md-offset-3 text-center">
				<div class="mockup-content">
						<div class="morph-button wow pulse morph-button-inflow morph-button-inflow-1">
						<?include("button-exit.php")?>
						<a class="btn btn-success" onclick="window.location.replace('/vote4/<?=$voting->votinglicense?>/<?=$vhash?>');return false;" role="button"><?t("Enter to voting")?> <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></a> 
						</div>
				</div>
			</div>	
		  </div>
		</div>
	</div>	
    
	
