	<!--benvinguda -->
    	<div id="info" class="content-section-b ">
		<div class="container">
		  <div class="row">
          <div class="container">
		
        
            <div class="row bs-wizard" style="border-bottom:0;">
                
              <div class="col-xs-4 bs-wizard-step complete">
                  <div class="text-center bs-wizard-stepnum"><?t("Wellcome")?></div>
                 <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step complete"><!-- complete -->
                  <div class="text-center bs-wizard-stepnum"><?t("Voting")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step active"><!-- complete -->
                  <div class="text-center bs-wizard-stepnum"><?t("Validation")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
                
              <div class="col-xs-4 bs-wizard-step disabled"><!-- active -->
                  <div class="text-center bs-wizard-stepnum"><?t("Ticket")?></div>
                  <div class="progress"><div class="progress-bar"></div></div>
                  <a href="#" class="bs-wizard-dot"></a>
                </div>
            </div>  
	</div>
		<div class="container">
		  <div class="row">

<form method="post" >
<input type="hidden" name="confirming1" value="1">

			<div class="col-md-6 col-md-offset-3 text-center">
				<h2><?t("Validation")?> </h2>
				<p class="lead">Vostè ha triat:</p>
<? 

foreach (getQuestions($voting) as $question) { 
$qn++;?>

	<h4><?=$question->{"statement_lang$lang"}?></h4>
	<div style="width:100%;"><center>
<?
	$hasOptions=0;	
	$on=0;
	foreach($_POST as $o=>$v) if (fnmatch("$_SESSION[votetoken1]-$question->questionlicense-*",$o)) { ?>

	
		<div class="lead" style="width:auto; width:30%; margin:5px; background:#if5f5f5;border:1px solid #8f8f8f; border-radius:8px; padding:8px ">
	<?
		if ($question->orderable) {
			$on ++;
			$options=getOptions($question);
			$points=sizeof($options)+1-$on;
		} else $points=1;
	?>
		<input type="hidden" name="<?=$o?>" value="<?=md5("9eKrat87EA.".$points.".B.9OLz.9ea")?>">
	<?		
		$option=optionOfLic(str_replace("$_SESSION[votetoken1]-$question->questionlicense-","",$o));
		if (!$option) continue;
		$hasOptions=1;

		if (strlen($option->logo)) { ?><img src="https://cdn.vota.online/upsource/<?=$option->optionlicense?>" alt="" width="" height="62" ><br><? } ?>
		<h4 style="margin:5px"><?if (!$text=$option->{"statement_lang$lang"}) $text=$option->name; echo $text?>
		<? if ($question->orderable) echo ": $points ".t($points>1?"points":"point",1)?> </h4>
		</div>
	<? }  
		if (!$hasOptions) { 
			?>
			<input type="hidden" name="<?="$_SESSION[votetoken1]-$question->questionlicense-DZBMP8RO-88MVU-ZPTQ0-CBDX1WBV-RWYSCBSN"?>" value="1">
			 <h4><?t("white vote")?></h4> <? 
		}
	?>
	</center></div>
	
<? } ?>
			 </div>
			<div class="col-md-6 col-md-offset-3 text-center">
				<div class="mockup-content">
						<div class="morph-button wow pulse morph-button-inflow morph-button-inflow-1">
							<button type="button "><span></span></button>
						</div>
				</div>
			</div>	
			</div>
<center>
<?include "button-exit.php"?>
<a class="btn btn-embossed btn-primary" onclick="window.location.replace('<?="/vote4/$voting->votinglicense/$_SESSION[identifier]"?>');return false;" role="button"><i class="fa fa-arrow-left" aria-hidden="true"></i> Tornar enrere</a>
<button type="submit" class="btn btn-success" role="button"><i class="fa fa-check" aria-hidden="true"></i> Validar el vot</button>
</center>
</form>
		</div>
	</div>	
</div>	
	
