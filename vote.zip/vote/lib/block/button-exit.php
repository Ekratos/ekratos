<? if ($_SESSION['isqr']) { ?>
                                                        <a class="btn btn-embossed btn-primary" style="opacity:0.7" onclick="window.location.replace('/qr');return false;" href="#" role="button"><i class="fa fa-sign-out" aria-hidden="true"></i><?t("Exit")?></a>
<? } else { ?>
                                                        <a class="btn btn-embossed btn-primary" style="opacity:0.7" onclick="window.location.replace('/vote/');return false;" href="#" role="button"><i class="fa fa-sign-out" aria-hidden="true"></i><?t("Exit")?></a>
<? } ?>
