<?php

include_once "configEkratos.php";

if (defined('basics.php')) return;
define ('basics.php',1);


function logme($m=''){
	if (!$m) return;
	global $box;
	global $domain;
//	global $CONFIGverbose;
//	if(!$CONFIGverbose) return;
	$string='';
	$trace=debug_backtrace();
	if(isset($trace[0])) $caller=basename($trace[0]['file']);
//	print_R($trace);
//	echo ("\n#* ");
	$bb='';
	if ($box) $bb="export box='$box';" ;
	if ($domain) $bb="export box='$domain';" ;
	if ($domain && $box) $bb="export box='$box,$domain';" ;

	if (is_array($m)) $m=print_r($m,1);
	if (is_object($m)) $m=print_r($m,1);
	$m=str_replace("`","",$m);
	$m=str_replace('"','\"',$m);
	passthru("$bb logme from $caller \"$m\" &");
	return true;

	
	if (is_array($m)) print_r($m);
	else echo($m);
}

function query($q){
//	logme($q);
	global $link;
	global $affected;
	if (!isset($link)) {
		if (!defined('DBNAME')) $DBNAME="ezonebox_2";
		else $DBNAME=DBNAME;
		$link = @new mysqli(DBHOST,DBUSER,DBPASS,$DBNAME);
//		if (mysqli_connect_errno()) logme("Connect failed: %s\n", mysqli_connect_error()) and die("  Error: " . mysqli_error($link));
	        if (mysqli_connect_errno() and logme("error 482433: ". mysqli_connect_error())) return false;
	}
#	$t='';
#	ts($t);
	$result=$link->query("$q"); 
	if ($link->error) logme("error 5748: $q :: " . $link->error);
//	if ($link->error) die("error 5748: $q :: " . $link->error);
	$affected=$link->affected_rows;
#	logme("result $link->affected_rows rows ".tr($t));	
	if (!is_object($result)) return false;

	$return=array();
	while ($row = $result->fetch_assoc()) {
		$return[]=$row;
	}
	$result->free();
	return $return;
}

function qquery($q){
        global $link;
        global $affected;
//	logme($q);
        if (!isset($link)) {
	        if (!defined('DBNAME')) $DBNAME="ezonebox_2";
	        else $DBNAME=DBNAME;
		$link = @new mysqli(DBHOST,DBUSER,DBPASS,$DBNAME);
	        if (mysqli_connect_errno() and die("error 48243: ". mysqli_connect_error())) return false;
		$link->query("set names utf8");	
	}
        $result=$link->query($q);
	if ($link->error) die("error 458748: $q :: " . $link->error);
//	if ($link->error) die("error 458748: $q :: " . $link->error);
        if (!is_object($result)) return false;

        $return=array();
        while ($row = $result->fetch_object()) {
                $return[]=$row;
        }
        $result->free();
        return $return;
}
function insert_id() {
        global $wlink;
        return  $wlink->insert_id ;
}

function wquery($q){
        global $wlink;
        if (!isset($wlink)) {
	        if (!defined('DBNAME')) $DBNAME="ezonebox_2";
	        else $DBNAME=DBNAME;
                $wlink = @new mysqli(DBHOST,DBUSER,DBPASS,$DBNAME);
                if (mysqli_connect_errno() and logme("error 48243: ". mysqli_connect_error())) return false;
                $wlink->query("set names utf8");
        }
        $result=$wlink->query($q);
        if ($wlink->error) {
		$errormsg="error 258748: $q :: " . $wlink->error;
		logme($errormsg);
	}
	xalert(" $q -> $errormsg","error");	
//        if ($wlink->error) die("error 258748: $q :: " . $wlink->error);
//	logme("wquery $link->affected_rows changed");
	return  $wlink->affected_rows;
}
function xalert($msg,$info='',$error=''){
	if ($error) $m.="<div class=\"xalert error\"><i>$error</i></div>";
	if ($info) $m.="<div class=\"xalert info\"><b>$info</b></div>";
        if (is_array($msg) or is_object($msg)) $m.=nl2br(print_r($msg,1));
	else $m.=$msg;
	$_SERVER['xalert'][]=$m;
}


function mwquery($q){
        global $mwlink;
        global $mwlinkqueries;
	if ($q=='print') { echo "<pre>".print_r($mwlinkqueries,1)."</pre>" ; return; }
	if ($q=='return') return $mwlinkqueries ;
	if ($q!='commit') { $mwlinkqueries[]=$q; return; }
	if (empty($mwlinkqueries)) return;

//	logme($mwlinkqueries);	
        if (!isset($mwlink)) {
	        if (!defined('DBNAME')) $DBNAME="ezonebox_2";
	        else $DBNAME=DBNAME;
                $mwlink = @new mysqli(DBHOST,DBUSER,DBPASS,$DBNAME);
                if (mysqli_connect_errno() and logme("error 43213: ". mysqli_connect_error())) return false;
                $mwlink->query("set names utf8");
        }
	$t1_start = microtime(true); 
        $result=$mwlink->multi_query(implode(';',$mwlinkqueries));
	if ($mwlink->error) { 
			$errormsg.="error 51278: $q :: " . $mwlink->error;
                        logme("error 51278: $q :: " . $mwlink->error);
        }
		
//        xalert($mwlinkqueries,"mwquery",$errormsg);

	$t1_end = microtime(true);
//	logme ("debug multi_query execution time: ".number_format($t1_end - $t1_start,3)."s");
	$mwlinkqueries=array();
	$aff=0;
	while ($mwlink->next_result()) {
		$aff+=$mwlink->affected_rows;
//	        if ($mwlink->error) {
//			$errormsg.="error 51278: $q :: " . $mwlink->error;
//			logme("error 51278: $q :: " . $mwlink->error);
//		}
//	        if ($mwlink->error) die("error 51278: $q :: " . $mwlink->error);
	}

//	logme("wquery $link->affected_rows changed");
	return  $aff;
}

	
function squery($q){
//      logme($q);
        global $slink;
        global $affected;
        if (!isset($slink)) {
                $slink = @new mysqli(DBHOST,DBUSER,DBPASS,'ezonebox_stats');
//              if (mysqli_connect_errno()) logme("Connect failed: %s\n", mysqli_connect_error()) and logme("error 6643" . mysqli_error($glink)) and return false;
                if (mysqli_connect_errno() and logme("error 428243: ". mysqli_connect_error())) return false;
        }
#       $t='';
#       ts($t);
        $result=$slink->query("$q") ;
        if ($slink->error) logme("error 358748: $q :: " . $slink->error);
//        if ($slink->error) die("error 358748: $q :: " . $slink->error);
#        $affected=$slink->affected_rows;
#       logme("result $slink->affected_rows rows ".tr($t));     
        if (!is_object($result)) return false;

        $return=array();
        while ($row = $result->fetch_object()) {
                $return[]=$row;
        }
        $result->free();
        return $return;
}


function wsquery($q){
        global $wslink;
        if (!isset($wslink)) {
                $DBNAME="ezonebox_stats";
                $wslink = @new mysqli(DBHOST,DBUSER,DBPASS,$DBNAME);
                if (mysqli_connect_errno() and logme("error 41249: ". mysqli_connect_error())) return false;
                $wslink->query("set names utf8");
        }
        $result=$wslink->query($q);
        if ($wslink->error) $errormsg="error 58349: $q :: " . $wslink->error;

	
//        if ($wslink->error) die("error 58349: $q :: " . $wslink->error);
//      logme("wquery $wslink->affected_rows changed");
        return  $wslink->affected_rows;
}



function writeme($table,$id,$what){
	global $link;
	if (!isset($link)) {
        	if (!defined('DBNAME')) $DBNAME="ezonebox_2";
	        else $DBNAME=DBNAME;
		$link = new mysqli (DBHOST,DBUSER,DBPASS,$DBNAME);
	}
//	if (mysqli_connect_errno()) logme("Connect failed: %s\n", mysqli_connect_error()) and die("  Error: " . mysqli_error($link));
	        if (mysqli_connect_errno() and logme("error 483243: ". mysqli_connect_error())) return false;

	$q="update $table set $what where ${table}Id=$id";
	logme($q);

	$link->query($q)
           or die("  Error: " . $link->error);

	logme("result $link->affected_rows changed");
}

function e($e){ 
	echo trim($e);
}


function all($entity,$name='') {
        $q="select * from $entity e where e.active='S'";
        if($name) $q="select * from $entity e where e.active='S' and e.name like '$name'";
        $result=@query($q);
        return($result);
}

function gv($field){
        global $entity;
	if ($field=='macaddr' or $field=='macaddr2') {
		$v=strtolower($entity[$field]);
                if (preg_match('/^[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}:[a-f0-9]{2}$/',$v)) return $v;
		else return "";
	}

//	if ($field=='macaddr') return str_replace('_','-',str_replace('.','-',trim($entity[$field])));
	if ($field=='devicename') return str_replace('_','-',str_replace('.','-',trim($entity[$field])));
	if ($field=='ezoneId') $field="roleId";
        if (isset($entity[$field])) return trim($entity[$field]);
}
function pv($field){
        echo gv($field);
}

function wget($url,$params=''){
    logme("debug getting '$url'");
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSLVERSION, 'CURL_SSLVERSION_TLSv1_1');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    if($params) {

	curl_setopt($ch,CURLOPT_POST, 1);
        $params = format_postdata_for_curlcall($params);
        curl_setopt($ch,CURLOPT_POSTFIELDS, $params);

      }

//    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//    curl_setopt($ch, CURLOPT_SSLVERSION,3); 
    $result = curl_exec($ch);
    logme ("debug transfer time: ". curl_getinfo ($ch,CURLINFO_TOTAL_TIME));

    if (curl_error($ch)) logme("error ".curl_error($ch));
    curl_close($ch);
    return $result;
}

function format_postdata_for_curlcall($postdata) {
        if (is_object($postdata)) {
            $postdata = (array) $postdata;
        }
        $data = array();
        foreach ($postdata as $k=>$v) {
            if (is_object($v)) {
                $v = (array) $v;
            }
            if (is_array($v)) {
                $currentdata = urlencode($k);
                format_array_postdata_for_curlcall($v, $currentdata, $data);
            }  else {
                $data[] = urlencode($k).'='.urlencode($v);
            }
        }
        $convertedpostdata = implode('&', $data);
        return $convertedpostdata;
    }

 function format_array_postdata_for_curlcall($arraydata, $currentdata, &$data) {
        foreach ($arraydata as $k=>$v) {
            $newcurrentdata = $currentdata;
            if (is_object($v)) {
                $v = (array) $v;
            }
            if (is_array($v)) { //the value is an array, call the function recursively
                $newcurrentdata = $newcurrentdata.'['.urlencode($k).']';
                format_array_postdata_for_curlcall($v, $newcurrentdata, $data);
            }  else { //add the POST parameter to the $data array
                $data[] = $newcurrentdata.'['.urlencode($k).']='.urlencode($v);
            }
        }
    }


function ts(&$timer=''){ # time set
	global  $starttime;
	list ($msec, $sec) = explode(' ', microtime());   
	if ($timer) $timer = (float)$msec + (float)$sec;
	else $starttime = (float)$msec + (float)$sec;
}

function tr($timer=''){ #time return
	global  $starttime;
	list ($msec, $sec) = explode(' ', microtime());   
	if ($timer) $totaltime = round( (float)$msec + (float)$sec - $timer, 3);
	else $totaltime = round( (float)$msec + (float)$sec - $starttime, 3); 
	return " [$totaltime"."s]\n";
}

function tp($timer=''){ #time print
	global  $starttime;
	echo tr($timer);
}

function validMac($mac=''){
#  if (filter_var($mac, FILTER_VALIDATE_MAC)) return $mac;
  if (preg_match('/([a-fA-F0-9]{2}[:|\-]?){6}/', $mac) == 1) return $mac;
  else logme("!! Invalid mac: $mac");
}
function validIp($ip=''){
  if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
  else logme("!! Invalid ip: $ip");
}

function utilCleanArray($ddata) {
        $maxCol=0;
        foreach ($ddata as $row) {
                if (!isset($header)) $header=$row;
                else $data[]=$row;
                foreach ($row as $id=>$val) if ($val and $id>$maxCol) $maxCol=$id;
        }

        foreach ($header as $id=>$val) if ($id > $maxCol) unset($header[$id]);
        foreach ($data as $idd=>$row) {
		$isempty=1;
		foreach($row as $id=>$val) {
			if ($val) $isempty=0;
                        unset($data[$idd][$id]);
                        if ($id > $maxCol) continue;
                        $name=$header[$id];
                        $data[$idd][$name]=$val;
		}
		if ($isempty) unset($data[$idd]);
        }

        return $data;
}

?>
