<?php

if (defined('config.php')) return;
define ('config.php',1);

//PROD
if (!defined('DBHOST')) define('DBHOST', 'localhost');
if (!defined('DBUSER')) define('DBUSER', 'user');
if (!defined('DBPASS')) define('DBPASS', 'password');
if (!defined('DBNAME')) define('DBNAME', 'basededades');

define("uploads","/uploads/");
define("langs","ca,es,en");

?>
