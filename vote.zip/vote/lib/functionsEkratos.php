<?
include_once "basicsEkratos.php";
session_start();

$peticion=array();
if(isset($_SERVER['REQUEST_URI'])) $peticion=explode("/",str_replace("?","/",$_SERVER['REQUEST_URI']));

array_shift($peticion);
$uri=implode("/",$peticion);

function t($name,$return=false,$noedit=false){
//      if ($return) return $name;
//        print $name;
//      return;
        global $lang;
        if ($lang=='c' and $return) return $name;
        elseif ($lang=='c') {print $name; return;} 
        $r=qquery("select textId,content_lang$lang as content from text where name='$name'");
        $r=$r[0];
        if ($r->content) $ret=nl2br($r->content);
        else $ret="$name *";
        if ($_SESSION['myedit'] and !$noedit) {$ret.='<a edithref="https://admin.vota.online/b?view,,listCard,,entity,,text,,entityId,,'.$r->textId.',,oper,,alone"> <svg class="Icon"><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#chat-bubbles"></use></svg></a>';}

        if ($return) return $ret;
        print $ret;
}
function institutionOf($elem){
        if ($elem->votingId) $res=qquery("select * from institution i
                join rel__institution_voting_votinginstitution v on (v.votingId=$elem->votingId and i.institutionId=v.institutionId)  where i.active='S'");
        if (empty($res)) return false;
        return (current($res));


}

function getQuestions($voting){
        $res=qquery("select * from question q
                join rel__question_voting_votingquestion v on (v.votingId=$voting->votingId and q.questionId=v.questionId)
		where q.active='S'
                ");
        if (empty($res)) return false;
        return ($res);
}
function getOptions($question){
        $res=qquery("select * from `option` o
                join rel__option_question_questionoptions q on (q.questionId=$question->questionId and o.optionId=q.optionId)
		where o.active='S'
                ");
        if (empty($res)) return false;
        return ($res);
}
function genLicense(){
   return(generateRandomString(8)."-".generateRandomString(5)."-".generateRandomString(5)."-".generateRandomString(8))."-".generateRandomString(8);
}
function generateRandomString($length = 10) {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

function votingOfLic($votingLic){
	if (!fnmatch("[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]",$votingLic)) return;
	$votingLic=mysql_escape_string($votingLic);
	$voting=current(qquery("select * from voting where votinglicense='$votingLic' and active='S'"));
//	xalert("voting: $voting->votingId");
	if (!$voting or !$voting->votingId) return false;
	return $voting;
}

function optionOfLic($optionLic){
        if (!fnmatch("[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]",$optionLic)) return;
        $optionLic=mysql_escape_string($optionLic);
        $option=current(qquery("select * from `option` where optionlicense='$optionLic' and active='S'"));
//      xalert("option: $option->optionId");
        if (!$option or !$option->optionId) return false;
        return $option;
}

function censusOf($elem){
        if ($elem->votingId) $res=qquery("select * from census c
                join rel__census_voting_censusvoting v on (v.votingId=$elem->votingId and c.censusId=v.censusId)
                where c.active='S'");
        if ($elem->voterId) $res=qquery("select * from census c
                join rel__census_voter_censusvoters r on (c.censusId=r.censusId and r.voterId=$elem->voterId)");
        if (empty($res)) return false;
        return (current($res));
}

function SfieldsOf($voting,$what=''){
	$census=censusOf($voting);

        for($i=1;$i<10;$i++) {
                $sf="statistic".str_pad($i,2,'0',STR_PAD_LEFT);
                if (!$census->$sf) continue;
                $statistic["name"]=$census->$sf;
                $statistic["id"]=$sf;
                $res[]=(object) $statistic;
        }
        return $res;
}
function AfieldsOf($voting,$what=''){
	$census=censusOf($voting);
        for($i=1;$i<10;$i++) {
                $sf="auto".str_pad($i,2,'0',STR_PAD_LEFT);
                if (!$autofield=$census->$sf) continue;
                list($field,$function)=explode(",",$autofield);
                $return["name"]=t($function,1);
                $return["id"]=$sf;
                $res[]=(object) $return;
        }
        return $res;
}

function killsession($fail){
		logme("Warning kill session fail: $fail");
		if ($_SESSION['error']) $_SERVER['error']=$_SESSION['error'];
		$isqr=$_SESSION['isqr'];
		$xalert=$_SESSION['xalert'];
                $lang=$_SESSION['lang'];
		$token1=$_SESSION['token1'];
                foreach ($_SESSION as $K=>$v) unset($_SESSION[$k]);
                session_destroy();
                session_start();
                if($xalert) $_SESSION['xalert']=$alert;
                if($token1) $_SESSION['token1']=$token1;
                if($isqr) $_SESSION['isqr']=$isqr;
                if (isset($_SESSION['identifier'])) unset($_SESSION['identifier']);
                if (isset($_SESSION['statistic'])) unset($_SESSION['statistic']);
}
function voterOfIdent($vhash){
        if (!$vhash) return;
        if (!fnmatch("[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]",$vhash)) return;
        $vhash=mysql_escape_string($vhash);
        $voter=current(qquery("select * from voter where hash='$vhash' "));
//      xalert("voter: $voter->voterId");
        if (!$voter or !$voter->voterId) return false;
        return $voter;
}

function votingOfIdent($vhash,$ident=''){
	if (!$vhash) return;
	if (!fnmatch("[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]-[0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z][0-Z]",$vhash)) return;
	$ident=mysql_escape_string($ident);
	$vhash=mysql_escape_string($vhash);
	if ($ident) $voter=current(qquery("select * from voter where hash='$vhash' and private01='$ident' and active='S'"));
	else $voter=current(qquery("select voterId from voter where hash='$vhash' and active='S'"));
	xalert("hash: $vhash, ident: $ident, id: $voter->voterId",'votingOfIdent voter');
	if (!$voter or !$voter->voterId) return false;

	$census=current(qquery("select censusId from rel__census_voter_censusvoters where voterId=$voter->voterId"));
	if (!$census or !$census->censusId) return false;
	xalert("id: $census->censusId",'votingOfIdent census');
	
	$voting=current(qquery("select * from voting v join rel__census_voting_censusvoting r on(v.votingId=r.votingId and v.active='S' and r.censusId=$census->censusId)"));
	xalert("id: $voting->votingId",'votingOfIdent voting');
	if (!$voting or !$voting->votingId) return false;

	return $voting;
}
?>
