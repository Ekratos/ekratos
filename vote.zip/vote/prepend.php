<?php

if (!function_exists("mysql_connect")) {

function mysql_escape_string($a) {
	return $a;
}

function mysql_connect($h,$u,$p) {
	global $globalConn;
	$globalConn=mysqli_connect($h,$u,$p);

	return $globalConn;
}


function mysql_select_db($b,$con=''){
	global $globalConn;
	if (!$con) $con=$globalConn;
	return mysqli_select_db($con,$b);
	
}

function mysql_query($q){
	global $globalConn;
	return mysqli_query($globalConn,$q);

	
}

function mysql_fetch_array($res,$mes=''){
	if($mes) return  mysqli_fetch_array($res,$mes);
	else return  mysqli_fetch_array($res);
}
}

?>


