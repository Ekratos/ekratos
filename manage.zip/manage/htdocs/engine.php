<?include_once "functionsEkratos.php";?>
<?
$blocks=array();
include "usersEkratos.php";
$current=array_shift($peticion);
switch ($current) {

case 'overview': 
case 'config':
case 'voters':
case 'census':
case 'census-download':
case 'voting-delete':
case 'participation':
case 'questions':
case 'content':
case 'results': 
case 'results-download': 
case 'combo': 
case 'add-config':
case 'add-voters':
case 'add-questions':
case 'add-content':
case 'add-complete':
case 'voter-detail':
case 'voter-remove':
case 'voter-removed':
case 'voter-saved':
case 'voter-email-template':
case 'preview-email':
case 'preview-vote';
case 'genqr';
case 'printqr';
case 'test-send';
case 'voter-ident';

		$votingLic=array_shift($peticion);
                if (!$votingLic) { $current='notfound' ; break; } 
                $voting=current(getVotings($globalUser,$votingLic));
                if (!$voting->votingId) {  $current="notfound";  break; }
		$institution=institutionOf($voting);
		break;
}
$langs=explode(",",$institution->langs);
if (!$_SESSION['add-voting-hash']) $_SESSION['add-voting-hash']=generateRandomString(8);
if (count($_POST)) include "savingEkratos.php";
if ($_POST['next']) {
	if($current=='add-voters') die( "<script>location='/add-content/$voting->votinglicense'</script>");
	if($current=='add-config') die( "<script>location='/add-voters/$voting->votinglicense'</script>");
        if($current=='add-questions') die( "<script>location='/add-complete/$voting->votinglicense'</script>");


	if ($current=='upload census') die( "<script>location='/add-content/$voting->votinglicense?l=".current($langs)."'</script>");
        if ($current=='add-content') {
		$langs=explode(",",$institution->langs);
                foreach ($langs as $clang){
                        if ($nextlang) die("<script>location='/add-content/$voting->votinglicense?l=$clang'</script>");
                        if ($clang==$_POST['l']) $nextlang=1;
                }
                die( "<script>location='/add-questions/$voting->votinglicense'</script>");
        }


}

//if ($current=='add-voters' and emptyCensus($voting)) $current='add-voters-empty';
//if ($current=='voters' and emptyCensus($voting)) $current='voters-empty';
xalert($current,"current");
switch ($current) {
case 'voter-email-template':
case 'preview-email';
case 'genqr';
case 'printqr';
case 'voter-ident';
case 'census-download':
case 'results-download':
case 'voting-delete':
		$_GET['simple']=1;
		$blocks[]=$current;
		break;
case 'preview-vote';
		$_GET['simple']=1;
		$blocks[]='preview-head';
		$blocks[]=$current;
		$blocks[]='preview-footer';
		break;
case 'overview': 
case 'census':
case 'participation':
case 'results': 
case 'combo': 
		$blocks[]="menu";
		$blocks[]="voting-menu";
		$blocks[]=$current;
		break;
case 'config':
case 'content':
		$blocks[]="menu";
                $blocks[]="voting-menu";
		$blocks[]="add-$current";	
		$blocks[]="button-save";
		break;
case 'voters':
case 'questions':
		$blocks[]="menu";
                $blocks[]="voting-menu";
                $blocks[]="add-$current";
                break;

case 'add-config':
case 'add-content':
case 'add-questions':
                $blocks[]="menu";
                $blocks[]="add-buttons";
                $blocks[]=$current;
                $blocks[]="button-next";
                break;
case 'add-voters':
		$blocks[]="menu";
                $blocks[]="add-buttons";
                $blocks[]=$current;
                $blocks[]="button-next-alone";
		break;

case 'add-complete':
		$blocks[]="menu";
                $blocks[]="add-buttons";
                $blocks[]=$current;
                $blocks[]="voting-menu";
		break;

case 'add-voting':
		$blocks[]="menu";
		$blocks[]=$current;
		$blocks[]="list";
                break;
case 'voter-detail':
case 'voter-saved':
case 'voter-remove':
case 'voter-removed':
case 'user-detail':
case 'user-saved':
case 'user-remove':
case 'user-removed':
case 'institution-saved':
case 'institution-remove':
case 'institution-removed':

case 'question-detail':
case 'question-saved':
case 'question-remove':
case 'question-removed':
case 'option-detail':
case 'option-saved':
case 'option-remove':
case 'option-removed':
case 'voter-send':
case 'user-send-password':
case 'open-institution':
case 'test-send':
		$blocks[]=$current;
		 break;
case '':
case 'home':
		$current="votings";
case 'institutions':
case 'users':
case 'votings':
		array_shift($peticion);
		$blocks[]="menu";
                $blocks[]="voting-menu";
                $blocks[]="$current";
                break;
default:	
		$blocks[]="menu";
		$blocks[]="notfound";
		header("HTTP/1.0 404 Not Found");
		logme("error file not found $_SERVER[REQUEST_URI]");
		break;
}
	
if (!$_GET['simple']) { ?>

<!DOCTYPE html>
<html id="html" class="js localstorage geolocation canvas audio video texttrackapi track flexbox mediaqueries cssanimations blobconstructor blob-constructor formdata no-saveblob formvalidation fieldsetdisabled no-csstrackrange cssrangeinput styleableinputrange details">
<head>
<?include "block/head.php";?>
<?include "block/meta.php";?>
</head>
<body id="body">
<?include "block/corporative.php";?>
<style>
<?include "block/css";?>
</style>
<script>
<?include "block/js";?>
</script>
<?
$blocks[]='xalert';
$blocks[]='footer2';

}
xalert($blocks,"blocks");
foreach ($blocks as $block) {
	if(!$block) continue;
	if ($_SESSION['mydebug']) echo "<div style='position:absolute;min-width:100px;min-height:10px;background:#76b576;border-radius:5px;padding:5px;font-size:12px;color:black;z-index:90'>block/$block.php</div>";
//	echo "\n\n<a style='margin-top:-80px;position:absolute' name='$block'></a>\n";
	if (!$_GET['simple']) echo "<section class=\"site-wrapper\" id=\"block$block\">";
	include "block/$block.php";
	if (!$_GET['simple']) echo "</section>";
}
?>

<? if (!$_GET['simple']) { ?>
</body>
</html>
<? } ?>
