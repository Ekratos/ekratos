<?

echo utf8_decode(file_get_contents("index.html"));

?>
