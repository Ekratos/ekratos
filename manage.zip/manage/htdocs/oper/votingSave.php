<?include_once "../../lib/functionsEkratos.php";?>
<?include_once "../../lib/usersEkratos.php";?>
<? 
if (!$editingMode) return;
foreach ($_POST as $k=>$val) $_POST[mysql_escape_string($k)]=mysql_escape_string($val);
foreach ($_POST as $k=>$val){
	if ($k=='votinglicense') $votinglicense=$val;
	if ($k=='files') continue;
	else $searchQ[]="$k='$val'";
}
	$searchQuery="update voting set ".implode(",",$searchQ)." where votinglicense='$votinglicense'";
	wquery("$searchQuery");
	$voting=current(getVotings($institution,$votinglicense));
?>
<html><body style="padding:0; margin:0">
<div style="width:300px;height:300px;background:#5cb85c;padding:6px 16px; color:white">guardat</div>
<?print_r($_POST)?>

