<?include_once "../../lib/functionsEkratos.php";?>
<?include_once "../../lib/usersEkratos.php";?>
<?

$table="census";

foreach ($_POST as $k=>$val) $_POST[mysql_escape_string($k)]=mysql_escape_string($val);
foreach ($_GET as $k=>$val) $_GET[mysql_escape_string($k)]=mysql_escape_string($val);

foreach ($_GET as $k=>$val){
	if ($k=='license') $license=$val;
	if ($k=='field' and fnmatch("statistic[0-9][0-9]",$val)) $field=$val;
	if ($k=='field' and $val=="name") $field=$val;
}

foreach ($_POST as $k=>$val){
        if ($k=='license') $license=$val;
	if (fnmatch("statistic[0-9][0-9]",$k)) { $field=$k;$searchQ[]="$k='$val'";}
	if ($k=='name') $searchQ[]="$k='$val'";
}

if (!$license) { sleep(3); echo "$table not found"; return;}
if (!$searchQ and !$field) { sleep(3); echo "field not found"; return;}
$elem=current(qquery("select * from $table where {$table}license='$license'"));
if (!$elem->{$table."Id"}) { sleep(3); echo "$table license not found"; return;}

?>

<? if ($_POST['license']) { 
	$aff=wquery("update $table set ".implode(",",$searchQ)." where {$table}license='$license'");
	$elem=current(qquery("select * from $table where {$table}license='$license'"));
?>
<html><body style="padding:0; margin:0">
<div id="guardatOk" style="width:300px;height:300px;background:#5cb85c;padding:6px 16px; color:white">guardat</div>
<div id="savedValue" value='<?=str_replace("'","&#39;",$elem->$field)?>'></div>
<script>setTimeout(function(){document.getElementById("guardatOk").style.background="white"}, 3000)</script>
<script>window.onload = function() {    parent.savingLoaded();}</script>

<?print_r($_POST)?>
	
	
<? } else { ?>
<form action="/<?=basename(dirname(__FILE__))?>/<?=basename(__FILE__)?>" method="post" target="operIframe">
<div class="form-group">
<input type="hidden" name="license" value="<?=$license?>">

<div class="input-group" style="margin:8px">
      <span class="input-group-addon" style="width:120px">name</span>
      <input name="" nameifchanged="<?=$field?>" value="<?=$elem->$field?>" type="text" class="form-control">
</div>

<div class="input-group" style="margin:8px">
	<div class="operIframeParent" ><iframe name="operIframe"></iframe></div>
	<input type="submit" class="btn btn-primary" value="Guardar" style="width:90px;margin-left:10px"></input>
	<button type="button" class="btn btn-info" closeCloned="1" style="width:90px;margin-left:10px">Tancar</button>
</div>

</div>
</form>
<? } ?>







