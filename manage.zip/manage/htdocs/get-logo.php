<?
include "../lib/functionsEkratos.php";

$cache="../cache/";
$uploads="../uploads/";

$license=mysql_escape_string($_GET['license']);
$bn=mysql_escape_string($_GET['bn']);
$h=mysql_escape_string($_GET['h']);
$w=mysql_escape_string($_GET['w']);

if ($license) $cont=current(qquery("select logo as image from institution where institutionlicense='$license' and active='S' and logo<>'' "));

list($filename,$filetype)=explode(":",$cont->image);
if (!$filename or !is_file("$uploads/$filename")) $filename="logo-black.png";

copy("$uploads/$filename","$cache/$filename");

if ($bn) {
	$newfilename="bn.$filename";
	if (!is_file("$cache/$newfilename")) exec ("convert -colorspace Gray -level -25% '$cache/$filename' '$cache/$newfilename'");
	$filename=$newfilename;
}

if ($h) {
	$newfilename="h$h.$filename";
	if (!is_file("$cache/$newfilename")) exec ("convert -resize x$h\> '$cache/$filename' '$cache/$newfilename'");
	$filename=$newfilename;
}

if ($w) {
        $newfilename="w$w.$filename";
        if (!is_file("$cache/$newfilename")) exec ("convert -resize ${w}x\> '$cache/$filename' '$cache/$newfilename'");
        $filename=$newfilename;
}


//		header("Expires: Sat, 26 Jul 2020 05:00:00 GMT");
                header('Accept-Ranges: bytes');
                header("Content-Length: " .(string)(filesize("$cache/$filename")) );
                header('Content-Type: '.$filetype);
                header('Last-Modified: '.gmdate('D, d M Y H:i:s', filemtime("$cache/$filename")));
                echo file_get_contents("$cache/$filename");
		flush();
		exec ("find $cache -type f -mtime +5 -delete > /dev/null &");

?>
