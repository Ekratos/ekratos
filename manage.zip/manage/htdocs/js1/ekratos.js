
$(document).on("click",".dash-content-header",function(){
//	$(".dash-content-header").parents(".listCard").slideUp(300,function(){ $(this).remove();showOpenedCards();}).dequeue();
	$(this).attr("self",1);
	$(this).parents("section").find(".dash-content-header:not([self])").slideUp(100).dequeue();
	$(this).parents("section").find(".separator").slideUp(100).dequeue();
});


$(document).on("click","[dest]",function(event){
//	alert($(this).attr('dest'));
	var dest=$(this).attr('dest');
	var destzone=$(this).attr('destzone');
	if (!destzone)  location=dest;
	else if (destzone=="replace")  window.location.replace(dest);
	else if (destzone=="new")  window.open(dest);
	else $("#"+destzone).attr('src',dest);
});
$(document).on("click","[oper]",function(event){
	var call=$(this).attr('oper')+"?simple=1";
	if ($(this).attr('oper').indexOf("?") >= 0) call=$(this).attr('oper')+"&simple=1";
	$("#cloned").slideUp(200).remove();
//	$(".oper-active").removeClass("oper-active");
//	$(this).addClass("oper-active");
	var content=$("#toClone").clone().attr("id","cloned");
	var row=$(this).closest("tr");
	if ($(this).is("tr")) row=this;
	$(row).after(content);
        $("#cloned td").attr("colspan",row.closest("tbody").first("tr").find("td").length);
	$.get(call,function(data){
                $("#cloned .content").html(data).slideDown(500);
        });
});

$(document).on("click","button[closeCloned]",function(event){
	$("#cloned").slideUp(500).remove();
});

$(document).on("change","[nameifchanged]",function(event){
	var name=$(this).attr("nameifchanged");
	$(this).attr("name",name);
});
function savingLoaded(){
	
	var rowContent=$("iframe[name='operIframe']").contents().find("#savedValue").find("tr").html(); //attr("html");
	$("iframe[name='operIframe']").closest("tr").prev().html(rowContent);
}
function deletingLoaded(){
        $("iframe[name='operIframe']").closest("tr").prev().remove();
        $("iframe[name='operIframe']").closest("tr").remove();
}


$(document).on("mouseover keyup keypress",".note-editor",function(event){
	$(this).next("textarea").val($(this).find(".note-editable").html());
});

$(document).on("click","[autoresize]",function(event){
	$("body").append('<div preview style="width:100%;height:100%;position:fixed;text-align:center; top:0; left:0; background:rgba(0,0,0,0.8);z-index:100"><img style="margin-top:25%; width:90%" src="'+$(this).attr("src")+'"><br><br><button type="button" class="btn btn-corporative">close</button></div>');
});

$(document).on("click","[preview]",function(event){
	$(this).remove();
});


$(document).ready(function() {
//  if ($('.summernote').hasClass("summernote"))   $('.summernote').summernote();
//	if ($('.sample-selector')) $('.sample-selector').colorpicker();
});
$(document).on("change keyup","input[testduplicated]",function(event){
	if (doubleblock) return;
        doubleblock=1;
        setTimeout(disdouble, 100);

	var id=$(this).val();
	$.get("/voter-ident/"+$(this).attr("votinglicense")+"/"+id, function(data){
		      if (data.charAt(0)=='X') {
			$("#duplicated").show() ;
			$("#voter-save").attr("disabled",1);
		     }
       		      else {
			$("#duplicated").hide() ;
			$("#voter-save").removeAttr("disabled");
		      }
	});

        
});

$(document).ready(function() {
	$("input[name='q']").after('<i class="glyphicon glyphicon-search "></i>');
	$("input[name='q']:not([value=''])").after('<span dest="?q=" class="input-remove"><i class="glyphicon glyphicon-remove"></i></span>');
	$("input[name='q'][value='']").after('<span dest="?q=" class="input-remove" style="display:none"><i class="glyphicon glyphicon-remove"></i></span>');
});

//$(document).ready(function() {
	//$( "input[type='date']" ).datepicker({ dateFormat: 'yyyy-mm-dd'});
//});

$(document).on("change click keyup keypress","input[name='q']",function(event){
	if ($(this).val())  $(this).parent().find('span.input-remove').show();
        else $(this).parent().find('span.input-remove').hide();
});

$(document).on("click","span.input-remove",function(event){
        $(this).parent().find("input[name='q']").val("");
	$(this).hide();
}); 
var doubleblock;
function disdouble(){
  		doubleblock=0;
}
$(document).on("click",".knob",function(event){
	if (doubleblock) return;
	doubleblock=1;
	setTimeout(disdouble, 100);
	var input=$(this).parents(".switch").find("input");
	if ($(input).attr("disabled")) return;
	name=$(input).attr("name");
	if (!$(input).hasClass("checked")){ 
		$(input).addClass("checked");
		$(input).val("S");
		$("input[depends='"+name+"']").removeAttr("disabled");
	} else {
		$(input).removeClass("checked");
                $(input).val("N");
		$("input[depends='"+name+"']").attr("disabled",1);

	}
});


