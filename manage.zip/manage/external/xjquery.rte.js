/*
* jQuery RTE plugin 0.5.1 - create a rich text form for Mozilla, Opera, Safari and Internet Explorer
*
* Copyright (c) 2009 Batiste Bieler
* Distributed under the GPL Licenses.
* Distributed under the The MIT License.
*/

// define the rte light plugin
(function($) {

    $.fn.rte = function(options) {

    $.fn.rte.html = function(iframe) {
        return iframe.contentWindow.document.getElementsByTagName("body")[0].innerHTML;
    };

    $.fn.rte.defaults = {
        media_url: "",
        content_css_url: "/stable/csslib.css",
        dot_net_button_class: null,
        max_height: 240
    };

    // build main options before element iteration
    var opts = $.extend($.fn.rte.defaults, options);

    // iterate and construct the RTEs
    return this.each( function() {

        var textarea = $(this);
        var iframe;
        var element_id = textarea.attr("id");

        // enable design mode
        function enableDesignMode() {

            var content = textarea.val();
//	alert(content+"ee");
            // Mozilla needs this to display caret
            if($.trim(content)=='') {
                content = '';
            }

            // already created? show/hide
            if(iframe) {
                textarea.hide();
                $(iframe).contents().find("body").html(content);
                $(iframe).show();
                $("#toolbar-" + element_id).remove();
                textarea.before(toolbar());
                return true;
            }

            // for compatibility reasons, need to be created this way
            iframe = document.createElement("iframe");
            iframe.frameBorder=0;
            iframe.frameMargin=0;
            iframe.framePadding=0;
//            iframe.height=200;
            if(textarea.attr('class'))   iframe.className = textarea.attr('class');
	    
            if(textarea.attr('id'))
                iframe.id = element_id+"_iframe";

            if(textarea.attr('name'))
                iframe.title = textarea.attr('name');

	    textarea.attr('expanded',1);
            //iframe.style.height = textarea.css('height');

            textarea.after(iframe);

//            var css = "<style>td {font-size:12px; font-family:fantasy; border-bottom:1px solid #333}</style>";
//            if(opts.content_css_url) {
//                css = "<link type='text/css' rel='stylesheet' href='" + opts.content_css_url + "' />";
  //          }
//            css = "<link type='text/css' rel='stylesheet' href='/cache/UMLX/2.2/csslib.css' />";
            css = "<style>#rte ,#rte td {font-size: 12px; font-family: sans-serif} #rte td {border-bottom: 1px solid #aaa;padding-left:4px} #rte tr td:first-child {background:#eee; font-weight:bold; white-space: no-wrap}	</style>";

            var doc = "<html><head>"+css+"</head><body id='rte' class='frameBody' >"+content+"</body></html>";

//                              alert($(this).contents().find("body").html());
           //        $(this).contents().find("body").html(doc);

	   $(iframe).load(function (){ 
            tryEnableDesignMode(doc, function() {
                $("#toolbar-" + element_id).remove();
                textarea.before(toolbar());
//		var bodye=$(iframe).contents().find("body");
//		$(bodye).scrollTop(2500);
//		info($(iframe).scrollTop());
//                if(($(bodye).scrollTop()>0)){
//                             $(bodye).css('height',$(bodye).height()+$(bodye).scrollTop()+'px');
//                             $(bodye).scrollTop(2500); //this.scrollTop=2500;
//                }
//                textarea.hide();
                // hide textarea
            });
           });

        }

        function tryEnableDesignMode(doc, callback) {
            if(!iframe) { return false; }
            try {
                iframe.contentWindow.document.open();
                iframe.contentWindow.document.write(doc);
                iframe.contentWindow.document.close();
            } catch(error) {
                //console.log(error);
            }
            if (document.contentEditable) {
                iframe.contentWindow.document.designMode = "On";
                callback();
                return true;
            }
            else if (document.designMode != null) {
                try {
                    iframe.contentWindow.document.designMode = "on";
                    callback();
                    return true;
                } catch (error) {
                    //console.log(error);
                }
            }
            setTimeout(function(){tryEnableDesignMode(doc, callback)}, 500);
            return false;
        }

        function disableDesignMode(submit) {
            var content = $(iframe).contents().find("body").html();

            if($(iframe).is(":visible")) {
                textarea.val(content);
            }

            if(submit != true) {
                textarea.show();
                $(iframe).hide();
            }
        }

        // create toolbar and bind events to it's elements
        function toolbar() {
            var tb = $("<div class='rte-toolbar' id='toolbar-"+ element_id +"'><div>\
                    <div class='bold' />\
                    <div class='italic' />\
                    <div class='unorderedlist' />\
                    <div class='link' />\
                    <div class='image' />\
                    <div class='disable' />\
                </div></div>");

            $('select', tb).change(function(){
                var index = this.selectedIndex;
                if( index!=0 ) {
                    var selected = this.options[index].value;
                    formatText("formatblock", '<'+selected+'>');
                }
            });
            $('.bold', tb).click(function(){ formatText('bold');return false; });
            $('.italic', tb).click(function(){ formatText('italic');return false; });
            $('.unorderedlist', tb).click(function(){ formatText('insertunorderedlist');return false; });
            $('.link', tb).click(function(){
                var p=prompt("URL:");
                if(p)
                    formatText('CreateLink', p);
                return false; });

            $('.image', tb).click(function(){
                var p=prompt("image URL:");
                if(p)
                    formatText('InsertImage', p);
                return false; });

            $('.disable', tb).click(function() {
                disableDesignMode();
                var edm = $('<a class="rte-edm" href="#">Enable design mode</a>');
                tb.empty().append(edm);
                edm.click(function(e){
                    e.preventDefault();
                    enableDesignMode();
                    // remove, for good measure
                    $(this).remove();
                });
                return false;
            });

            // .NET compatability
            if(opts.dot_net_button_class) {
                var dot_net_button = $(iframe).parents('form').find(opts.dot_net_button_class);
                dot_net_button.click(function() {
                    disableDesignMode(true);
                });
            // Regular forms
            } else {
                $(iframe).parents('form').submit(function(){
                    disableDesignMode(true);
                });
            }

            var iframeDoc = $(iframe.contentWindow.document);

            var select = $('select', tb)[0];
            iframeDoc.mouseup(function(){
                setSelectedType(getSelectionElement(), select);
                return true;
            });

//            iframeDoc.down(function() {
//		$("textarea.areaComments").trigger('keydown');
  //          });


	    iframeDoc.bind('keydown', function(){
//	    iframeDoc.keydown(function() {	
                var body = $('body', iframeDoc);
//		alert (body.html());
		$("#"+iframe.id.replace('_iframe','')).html(body.html());// $("#"+iframe.id).contents()[0].documentElement.body.innerHTML );
		$("#"+iframe.id.replace('_iframe','')).trigger('keydown');
	   });

	iframeDoc.each(function() {
                var elem = $('body', iframeDoc);
                $(iframe).css('height',$(elem).height()+10+'px');
        });

	iframeDoc.mouseover(function() {
		var elem = $('body', iframeDoc);
		$(elem).scrollTop(2500);
                if(($(elem).scrollTop()>0)){
                        $(iframe).css('height',$(elem).height()+$(elem).scrollTop()+10+'px');
                        $(elem).scrollTop(2500);
                }
	});
            iframeDoc.keyup(function() {
                setSelectedType(getSelectionElement(), select);
                var body = $('body', iframeDoc);
		var elem = body;
		$(elem).scrollTop(2500);
		if(($(elem).scrollTop()>0)){
	                $(iframe).css('height',$(elem).height()+$(elem).scrollTop()+10+'px');

		  	$(elem).scrollTop(2500);
		}

		$("#"+iframe.id.replace('_iframe','')).html( body.html());
		$("#"+iframe.id.replace('_iframe','')).trigger('keyup');
                return true;
            });

            return tb;
        };

        function formatText(command, option) {
//		alert("focus");
            iframe.contentWindow.focus();
            try{
                iframe.contentWindow.document.execCommand(command, false, option);
            }catch(e){
                //console.log(e)
            }
            iframe.contentWindow.focus();
            var iframeDoc = $(iframe.contentWindow.document);
	    iframeDoc.trigger('keyup');
        };

        function setSelectedType(node, select) {
            while(node.parentNode) {
                var nName = node.nodeName.toLowerCase();
                //for(var i=0;i<select.options.length;i++) {
                //    if(nName==select.options[i].value){
                //        select.selectedIndex=i;
                //        return true;
                //    }
                //}
                node = node.parentNode;
            }
            //select.selectedIndex=0;
            return true;
        };

        function getSelectionElement() {
            if (iframe.contentWindow.document.selection) {
                // IE selections
                selection = iframe.contentWindow.document.selection;
                range = selection.createRange();
                try {
                    node = range.parentElement();
                }
                catch (e) {
                    return false;
                }
            } else {
                // Mozilla selections
                try {
                    selection = iframe.contentWindow.getSelection();
                    range = selection.getRangeAt(0);
                }
                catch(e){
                    return false;
                }
                node = range.commonAncestorContainer;
            }
            return node;
        };

        // enable design mode now
        enableDesignMode();

    }); //return this.each
    
};// rte

})(jQuery);
